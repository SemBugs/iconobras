<template>
    <svg width="128" height="35" viewBox="0 0 128 35" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="0.558594" y="8.74414" width="126.786" height="3.66929" fill="#c65dca" />
        <rect x="0.558594" y="0.845703" width="126.786" height="3.66929" fill="#c65dca" />
        <rect x="2.23828" y="8.74414" width="4.22931" height="6.05047" transform="rotate(-90 2.23828 8.74414)"
            fill="#c65dca" />
        <rect x="118.051" y="8.74414" width="4.22931" height="6.05047" transform="rotate(-90 118.051 8.74414)"
            fill="#c65dca" />
        <rect x="0.558594" y="30.5371" width="126.786" height="3.66929" fill="#c65dca" />
        <rect x="0.558594" y="22.6387" width="126.786" height="3.66929" fill="#c65dca" />
        <rect x="2.23828" y="30.5371" width="4.22931" height="6.05047" transform="rotate(-90 2.23828 30.5371)"
            fill="#c65dca" />
        <rect x="118.051" y="30.5371" width="4.22931" height="6.05047" transform="rotate(-90 118.051 30.5371)"
            fill="#c65dca" />
    </svg>

</template>