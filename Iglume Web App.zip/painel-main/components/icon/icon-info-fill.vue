<template>
  <svg width="15" height="16" viewBox="0 0 15 16" fill="none"
       xmlns="http://www.w3.org/2000/svg">
    <path d="M7.22241 11.0557L7.22241 7.16678"
          stroke="#95979B" stroke-linecap="round"
          stroke-linejoin="round" />
    <path d="M7.22247 4.79639V4.72259" stroke="#95979B"
          stroke-linecap="round" stroke-linejoin="round" />
    <circle cx="7.5" cy="8" r="7"
            transform="rotate(-180 7.5 8)"
            stroke="#95979B" />
  </svg>
</template>
<script>
  export default {
    name: 'icon-info-fill'
  };
</script>