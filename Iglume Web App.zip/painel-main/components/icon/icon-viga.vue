<template>
    <svg width="62" height="46" viewBox="0 0 62 46" fill="none" xmlns="http://www.w3.org/2000/svg">
        <line y1="2.75592" x2="62" y2="2.75592" stroke="#DEDDDA" stroke-width="4"/>
        <path d="M5.42859 33.4113L13.8529 3.66937L22.2773 33.4113H5.42859Z" stroke="#DEDDDA" stroke-width="2"/>
        <path d="M23.546 33.4113L31.9704 3.66937L40.3947 33.4113H23.546Z" stroke="#DEDDDA" stroke-width="2"/>
        <path d="M42.3209 33.4113L50.7453 3.66937L59.1696 33.4113H42.3209Z" stroke="#DEDDDA" stroke-width="2"/>
        <path d="M0.220703 28.7031H61.9999V39.7623C61.9999 41.4192 60.6567 42.7623 58.9999 42.7623H3.2207C1.56385 42.7623 0.220703 41.4192 0.220703 39.7623V28.7031Z" fill="#C0B5B5"/>
        <path d="M0.220703 28.7031H61.9999V39.7623C61.9999 41.4192 60.6567 42.7623 58.9999 42.7623H3.2207C1.56385 42.7623 0.220703 41.4192 0.220703 39.7623V28.7031Z" stroke="#444444"/>
    </svg>
</template>
<script lang="ts" setup>
    defineProps({
        fill: {
            type: Boolean,
            default: false,
        },
    });
</script>
