<template>
   <svg width="74" height="46" viewBox="0 0 74 46" fill="none" xmlns="http://www.w3.org/2000/svg">
<line x1="0.81516" y1="25.1608" x2="43.555" y2="1.43288" stroke="black" stroke-width="1.5"/>
<line x1="4.10183" y1="14.2381" x2="48.0161" y2="43.541" stroke="black" stroke-width="1.5"/>
<line x1="13.4938" y1="9.62386" x2="57.4334" y2="36.9597" stroke="black" stroke-width="1.5"/>
<line x1="21.227" y1="5.35544" x2="65.7071" y2="29.5062" stroke="black" stroke-width="1.5"/>
<line x1="29.4" y1="1.41996" x2="73.2551" y2="23.679" stroke="black" stroke-width="1.5"/>
<line x1="8.92189" y1="30.5529" x2="51.5741" y2="5.36812" stroke="black" stroke-width="1.5"/>
<line x1="17.3248" y1="36.9668" x2="60.3835" y2="9.04012" stroke="black" stroke-width="1.5"/>
<line x1="27.0329" y1="44.5582" x2="69.6772" y2="13.1655" stroke="black" stroke-width="1.5"/>
</svg>

</template>