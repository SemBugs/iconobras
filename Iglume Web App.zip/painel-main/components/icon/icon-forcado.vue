<template>
    <svg width="57" height="73" viewBox="0 0 57 73" fill="none" xmlns="http://www.w3.org/2000/svg">
        <line x1="28.9492" y1="32.4473" x2="28.9492" y2="68.9849" stroke="#5dca9b" stroke-width="7"
            stroke-linecap="round" />
        <line x1="38.957" y1="50.3867" x2="17.9436" y2="50.3867" stroke="#5dca9b" stroke-width="7"
            stroke-linecap="round" />
        <line x1="0.558594" y1="28.4473" x2="56.3391" y2="28.4473" stroke="#5dca9b" stroke-width="7" />
        <line x1="52.8398" y1="3.78516" x2="52.8398" y2="28.4474" stroke="#5dca9b" stroke-width="7"
            stroke-linecap="round" />
        <line x1="3.95312" y1="28.4473" x2="3.95312" y2="3.78505" stroke="#5dca9b" stroke-width="7"
            stroke-linecap="round" />
    </svg>

</template>