export default [
    {
        "text": "Dinheiro",
        "value": "01"
    },
    {
        "text": "Transferência bancária",
        "value": "18"
    },
    {
        "text": "Pix",
        "value": "17"
    },
    {
        "text": "Cartão de Debito",
        "value": "04"
    },
    {
        "text": "Cartão de Crédito",
        "value": "03"
    },
    {
        "text": "Cheque",
        "value": "02"
    },
    {
        "text": "Crédito Loja",
        "value": "05"
    },
    {
        "text": "Vale Alimentação",
        "value": "10"
    },
    {
        "text": "Vale Presente",
        "value": "12"
    },
    {
        "text": "Vale Refeição",
        "value": "11"
    },
    {
        "text": "Vale Combustível",
        "value": "13"
    },
    {
        "text": "Boleto Bancário",
        "value": "15"
    },
    {
        "text": "Depósito Bancário",
        "value": "16"
    },
    {
        "text": "Sem pagamento",
        "value": "90"
    },
    {
        "text": "Outros",
        "value": "99"
    }
]